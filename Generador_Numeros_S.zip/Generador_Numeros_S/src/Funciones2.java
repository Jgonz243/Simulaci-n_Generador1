
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jhon Gonzales
 */
public class Funciones2 {
    ScriptEngineManager manager = new ScriptEngineManager(); 
    ScriptEngine interprete = manager.getEngineByName("js"); 
    String funcion2;

    public Funciones2(String funcion2) {
        this.funcion2=funcion2;
    }
    
    public double evaluar2(double numero2){
        try {
            interprete.put("G", numero2);
            double resultado2= (double) interprete.eval(this.funcion2);   
            return resultado2;
        } catch (ScriptException ex) {
            Logger.getLogger(Funciones2.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
}
